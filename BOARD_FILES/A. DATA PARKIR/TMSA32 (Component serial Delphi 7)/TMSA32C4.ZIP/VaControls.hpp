// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaControls.pas' rev: 4.00

#ifndef VaControlsHPP
#define VaControlsHPP

#pragma delphiheader begin
#pragma option push -w-
#include <ExtCtrls.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vacontrols
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS EVrException;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION EVrException : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EVrException(const AnsiString Msg) : Sysutils::Exception(Msg
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EVrException(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EVrException(int Ident, Extended Dummy) : Sysutils::Exception(
		Ident, Dummy) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EVrException(int Ident, const System::TVarRec * Args
		, const int Args_Size) : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EVrException(const AnsiString Msg, int AHelpContext) : 
		Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EVrException(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EVrException(int Ident, int AHelpContext) : Sysutils::Exception(
		Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EVrException(int Ident, const System::TVarRec * 
		Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Ident, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EVrException(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

typedef AnsiString TVrVersion;

#pragma option push -b-
enum TVrDrawStyle { dsOwnerDraw, dsNormal };
#pragma option pop

#pragma option push -b-
enum TVrTransparentMode { tmPixel, tmColor };
#pragma option pop

#pragma option push -b-
enum TVrTextAlignment { vtaLeft, vtaCenter, vtaRight, vtaTopLeft, vtaTop, vtaTopRight, vtaBottomLeft, 
	vtaBottom, vtaBottomRight };
#pragma option pop

#pragma option push -b-
enum TVrAlignment { vaLeftJustify, vaRightJustify, vaCenter };
#pragma option pop

#pragma option push -b-
enum TVrOrientation { voVertical, voHorizontal };
#pragma option pop

#pragma option push -b-
enum TVrImageTextLayout { ImageLeft, ImageRight, ImageTop, ImageBottom };
#pragma option pop

class DELPHICLASS TGraphicControlCanvas;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TGraphicControlCanvas : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
public:
	__property Canvas ;
public:
	#pragma option push -w-inl
	/* TGraphicControl.Create */ inline __fastcall virtual TGraphicControlCanvas(Classes::TComponent* AOwner
		) : Controls::TGraphicControl(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TGraphicControl.Destroy */ inline __fastcall virtual ~TGraphicControlCanvas(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TCustomControlCanvas;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TCustomControlCanvas : public Controls::TCustomControl 
{
	typedef Controls::TCustomControl inherited;
	
public:
	__property Canvas ;
public:
	#pragma option push -w-inl
	/* TCustomControl.Create */ inline __fastcall virtual TCustomControlCanvas(Classes::TComponent* AOwner
		) : Controls::TCustomControl(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TCustomControl.Destroy */ inline __fastcall virtual ~TCustomControlCanvas(void) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TWinControl.CreateParented */ inline __fastcall TCustomControlCanvas(HWND ParentWindow) : Controls::TCustomControl(
		ParentWindow) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TVaGraphicControl;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaGraphicControl : public Controls::TGraphicControl 
{
	typedef Controls::TGraphicControl inherited;
	
private:
	int FUpdateCount;
	Classes::TNotifyEvent FOnMouseEnter;
	Classes::TNotifyEvent FOnMouseLeave;
	Classes::TNotifyEvent FOnFontChanged;
	Classes::TNotifyEvent FOnTextChanged;
	HIDESBASE MESSAGE void __fastcall CMMouseEnter(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMMouseLeave(Messages::TMessage &Message);
	HIDESBASE MESSAGE void __fastcall CMFontChanged(Messages::TMessage &Message);
	MESSAGE void __fastcall CMTextChanged(Messages::TMessage &Message);
	
protected:
	bool __fastcall Designing(void);
	bool __fastcall Loading(void);
	void __fastcall ClearClientCanvas(void);
	virtual void __fastcall UpdateControlCanvas(void);
	virtual void __fastcall UpdateControlBounds(void);
	virtual void __fastcall AdjustControlSize(void);
	void __fastcall ShowDesignFrame(Graphics::TCanvas* Dest);
	virtual void __fastcall MouseEnter(void);
	virtual void __fastcall MouseLeave(void);
	HIDESBASE virtual void __fastcall FontChanged(void);
	virtual void __fastcall TextChanged(void);
	__property Classes::TNotifyEvent OnMouseEnter = {read=FOnMouseEnter, write=FOnMouseEnter};
	__property Classes::TNotifyEvent OnMouseLeave = {read=FOnMouseLeave, write=FOnMouseLeave};
	__property Classes::TNotifyEvent OnFontChanged = {read=FOnFontChanged, write=FOnFontChanged};
	__property Classes::TNotifyEvent OnTextChanged = {read=FOnTextChanged, write=FOnTextChanged};
	
public:
	__fastcall virtual TVaGraphicControl(Classes::TComponent* AOwner);
	void __fastcall BeginUpdate(void);
	void __fastcall EndUpdate(void);
public:
	#pragma option push -w-inl
	/* TGraphicControl.Destroy */ inline __fastcall virtual ~TVaGraphicControl(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
#define sValueOutOfRange "Value out of range."
extern PACKAGE int cfTextAlign[9];

}	/* namespace Vacontrols */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vacontrols;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaControls
