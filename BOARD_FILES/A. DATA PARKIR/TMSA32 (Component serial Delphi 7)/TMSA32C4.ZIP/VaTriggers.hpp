// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaTriggers.pas' rev: 4.00

#ifndef VaTriggersHPP
#define VaTriggersHPP

#pragma delphiheader begin
#pragma option push -w-
#include <VaInterface.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vatriggers
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TVaTimer;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaTimer : public Vaclasses::TVaComponent 
{
	typedef Vaclasses::TVaComponent inherited;
	
private:
	unsigned FInterval;
	HWND FWindowHandle;
	Classes::TNotifyEvent FOnTimer;
	bool FEnabled;
	void __fastcall UpdateTimer(void);
	void __fastcall SetEnabled(bool Value);
	void __fastcall SetInterval(unsigned Value);
	void __fastcall SetOnTimer(Classes::TNotifyEvent Value);
	void __fastcall WndProc(Messages::TMessage &Msg);
	
protected:
	DYNAMIC void __fastcall Timer(void);
	
public:
	__fastcall virtual TVaTimer(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaTimer(void);
	
__published:
	__property bool Enabled = {read=FEnabled, write=SetEnabled, default=1};
	__property unsigned Interval = {read=FInterval, write=SetInterval, default=1000};
	__property Classes::TNotifyEvent OnTimer = {read=FOnTimer, write=SetOnTimer};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vatriggers */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vatriggers;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaTriggers
