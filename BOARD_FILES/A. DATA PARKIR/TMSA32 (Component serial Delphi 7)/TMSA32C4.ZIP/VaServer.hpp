// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaServer.pas' rev: 4.00

#ifndef VaServerHPP
#define VaServerHPP

#pragma delphiheader begin
#pragma option push -w-
#include <VaPrst.hpp>	// Pascal unit
#include <VaUtils.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <VaTypes.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vaserver
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TVaServerClient;
class DELPHICLASS TVaServer;
typedef void __fastcall (__closure *TVaClientEvent)(System::TObject* Sender, TVaServerClient* Client
	);

typedef void __fastcall (__closure *TVaClientErrorEvent)(System::TObject* Sender, TVaServerClient* Client
	, int Errors);

typedef void __fastcall (__closure *TVaClientRxCharEvent)(System::TObject* Sender, TVaServerClient* 
	Client, int Count);

#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaServer : public Vaclasses::TVaComponent 
{
	typedef Vaclasses::TVaComponent inherited;
	
private:
	Classes::TList* FClients;
	TVaClientEvent FOnClientCts;
	TVaClientEvent FOnClientDsr;
	TVaClientEvent FOnClientRlsd;
	TVaClientEvent FOnClientRing;
	TVaClientEvent FOnClientBreak;
	TVaClientErrorEvent FOnClientError;
	TVaClientRxCharEvent FOnClientRxChar;
	TVaClientEvent FOnClientRxFlag;
	TVaClientEvent FOnClientTxEmpty;
	TVaClientEvent FOnClientPErr;
	TVaClientEvent FOnClientRx80Full;
	TVaClientEvent FOnClientEvent1;
	TVaClientEvent FOnClientEvent2;
	int __fastcall GetClientCount(void);
	TVaServerClient* __fastcall GetServerClient(int Index);
	
protected:
	void __fastcall AddClient(TVaServerClient* Client);
	void __fastcall RemoveClient(TVaServerClient* Client);
	void __fastcall SysError(AnsiString Msg, int ErrorCode);
	void __fastcall HandleDataEvent(TVaServerClient* Client);
	void __fastcall HandleLineEvent(TVaServerClient* Client, unsigned EvtMask);
	
public:
	__fastcall virtual TVaServer(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaServer(void);
	void __fastcall BroadCast(void *Buf, int Count);
	virtual void __fastcall CloseAll(void);
	__property TVaServerClient* ServerClient[int Index] = {read=GetServerClient};
	__property int ClientCount = {read=GetClientCount, nodefault};
	
__published:
	__property TVaClientEvent OnClientCts = {read=FOnClientCts, write=FOnClientCts};
	__property TVaClientEvent OnClientDsr = {read=FOnClientDsr, write=FOnClientDsr};
	__property TVaClientEvent OnClientRlsd = {read=FOnClientRlsd, write=FOnClientRlsd};
	__property TVaClientEvent OnClientRing = {read=FOnClientRing, write=FOnClientRing};
	__property TVaClientEvent OnClientBreak = {read=FOnClientBreak, write=FOnClientBreak};
	__property TVaClientErrorEvent OnClientError = {read=FOnClientError, write=FOnClientError};
	__property TVaClientRxCharEvent OnClientRxChar = {read=FOnClientRxChar, write=FOnClientRxChar};
	__property TVaClientEvent OnClientRxFlag = {read=FOnClientRxFlag, write=FOnClientRxFlag};
	__property TVaClientEvent OnClientTxEmpty = {read=FOnClientTxEmpty, write=FOnClientTxEmpty};
	__property TVaClientEvent OnClientPErr = {read=FOnClientPErr, write=FOnClientPErr};
	__property TVaClientEvent OnClientRx80Full = {read=FOnClientRx80Full, write=FOnClientRx80Full};
	__property TVaClientEvent OnClientEvent1 = {read=FOnClientEvent1, write=FOnClientEvent1};
	__property TVaClientEvent OnClientEvent2 = {read=FOnClientEvent2, write=FOnClientEvent2};
};

#pragma pack(pop)

#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaServerClient : public Vacomm::TVaCustomComm 
{
	typedef Vacomm::TVaCustomComm inherited;
	
private:
	TVaServer* FServer;
	void __fastcall SetServer(TVaServer* Value);
	
protected:
	virtual void __fastcall HandleDataEvent(void);
	virtual void __fastcall HandleLineEvent(unsigned EvtMask);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	
public:
	__fastcall virtual ~TVaServerClient(void);
	
__published:
	__property TVaServer* Server = {read=FServer, write=SetServer};
	__property AutoOpen ;
	__property Baudrate ;
	__property Parity ;
	__property Databits ;
	__property Stopbits ;
	__property EventChars ;
	__property FlowControl ;
	__property Options ;
	__property PortNum ;
	__property DeviceName ;
	__property MonitorEvents ;
	__property Buffers ;
	__property EventPriority ;
	__property WritePriority ;
	__property DirectWrite ;
	__property UpdateDCB ;
	__property UserBaudrate ;
	__property OnOpen ;
	__property OnClose ;
public:
	#pragma option push -w-inl
	/* TVaCustomComm.Create */ inline __fastcall virtual TVaServerClient(Classes::TComponent* AOwner) : 
		Vacomm::TVaCustomComm(AOwner) { }
	#pragma option pop
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vaserver */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vaserver;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaServer
