// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaComm.pas' rev: 4.00

#ifndef VaCommHPP
#define VaCommHPP

#pragma delphiheader begin
#pragma option push -w-
#include <Registry.hpp>	// Pascal unit
#include <VaDisplay.hpp>	// Pascal unit
#include <VaUtils.hpp>	// Pascal unit
#include <VaPrst.hpp>	// Pascal unit
#include <VaObjects.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <VaTypes.hpp>	// Pascal unit
#include <VaConst.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vacomm
{
//-- type declarations -------------------------------------------------------
typedef char TVaData[32768];

typedef char *PVaData;

typedef void __fastcall (__closure *TVaCommRxCharEvent)(System::TObject* Sender, int Count);

typedef void __fastcall (__closure *TVaCommRxBufEvent)(System::TObject* Sender, PVaData Data, int Count
	);

typedef void __fastcall (__closure *TVaCommErrorEvent)(System::TObject* Sender, int Errors);

typedef void __fastcall (__closure *TVaCommLineEvent)(System::TObject* Sender, unsigned EvtMask);

#pragma option push -b-
enum TVaCommEvent { ceBreak, ceCts, ceDsr, ceError, ceRing, ceRlsd, ceRxChar, ceTxEmpty, ceRxFlag, cePErr, 
	ceRx80Full, ceEvent1, ceEvent2 };
#pragma option pop

typedef Set<TVaCommEvent, ceBreak, ceEvent2>  TVaCommEvents;

#pragma option push -b-
enum TVaCommOption { coErrorChar, coNullStrip, coParityCheck };
#pragma option pop

typedef Set<TVaCommOption, coErrorChar, coParityCheck>  TVaCommOptions;

#pragma pack(push, 4)
struct TVaCommStatus
{
	unsigned Errors;
	_COMSTAT Status;
} ;
#pragma pack(pop)

#pragma option push -b-
enum TVaBaudrate { brUser, br110, br300, br600, br1200, br2400, br4800, br9600, br14400, br19200, br38400, 
	br56000, br57600, br115200, br128000, br256000 };
#pragma option pop

#pragma option push -b-
enum TVaParity { paNone, paOdd, paEven, paMark, paSpace };
#pragma option pop

#pragma option push -b-
enum TVaDatabits { db4, db5, db6, db7, db8 };
#pragma option pop

#pragma option push -b-
enum TVaStopbits { sb1, sb15, sb2 };
#pragma option pop

class DELPHICLASS TVaCommEventThread;
class DELPHICLASS TVaCustomComm;
class DELPHICLASS TVaCommWriteThread;
class DELPHICLASS TVaCommBuffer;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaCommBuffer : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	char *FData;
	int FSize;
	
public:
	__fastcall TVaCommBuffer(int BufSize);
	__fastcall virtual ~TVaCommBuffer(void);
	char * __fastcall DataPtr(void);
	void __fastcall Clear(void);
	void __fastcall Write(void *Buf, int Count);
	void __fastcall Read(void *Buf, int Count);
	void __fastcall Peek(void *Buf, int Count);
	void __fastcall Remove(int Count);
	__property int Size = {read=FSize, nodefault};
};

#pragma pack(pop)

#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaCommWriteThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	TVaCommBuffer* FBuffer;
	Vaobjects::TVaWaitEvent* FWriteEvent;
	Vaobjects::TVaWaitEvent* FCloseEvent;
	Vaobjects::TVaWaitEvent* FFlushEvent;
	Vaobjects::TVaWaitEvent* FFlushDoneEvent;
	Vaobjects::TVaWaitEvent* FOverlappedEvent;
	TVaCustomComm* FOwner;
	
protected:
	void __fastcall DoTxEmpty(void);
	void __fastcall DoWriteError(void);
	virtual void __fastcall Execute(void);
	void __fastcall StopThread(void);
	
public:
	__fastcall TVaCommWriteThread(TVaCustomComm* AOwner);
	__fastcall virtual ~TVaCommWriteThread(void);
	void __fastcall PurgeWrite(void);
	bool __fastcall WriteData(void *Buf, int Count);
	__property TVaCommBuffer* Buffer = {read=FBuffer};
};

#pragma pack(pop)

class DELPHICLASS TVaDispatcher;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaCustomComm : public Vaclasses::TVaComponent 
{
	typedef Vaclasses::TVaComponent inherited;
	
private:
	unsigned FHandle;
	Vaobjects::TVaCriticalSection* FWriteSection;
	Vaobjects::TVaCriticalSection* FGlobalSection;
	_COMMPROP FProperties;
	Vaobjects::TVaWaitEvent* FEvent;
	TVaCommEventThread* FEventThread;
	TVaCommWriteThread* FWriteThread;
	int FEventMask;
	bool FAutoOpen;
	Vatypes::TVaPortInt FPortNum;
	AnsiString FDeviceName;
	TVaCommEvents FMonitorEvents;
	Vaprst::TVaBuffers* FBuffers;
	Classes::TThreadPriority FEventPriority;
	Classes::TThreadPriority FWritePriority;
	bool FDirectWrite;
	bool FControlsEnabled;
	Classes::TList* FClients;
	TVaBaudrate FBaudrate;
	TVaParity FParity;
	TVaDatabits FDatabits;
	TVaStopbits FStopbits;
	TVaCommOptions FOptions;
	Vaprst::TVaFlowControl* FFlowControl;
	Vaprst::TVaEventChars* FEventChars;
	bool FUpdateDCB;
	int FUserBaudrate;
	Classes::TNotifyEvent FOnOpen;
	Classes::TNotifyEvent FOnClose;
	Classes::TNotifyEvent FOnCts;
	Classes::TNotifyEvent FOnDsr;
	Classes::TNotifyEvent FOnRlsd;
	Classes::TNotifyEvent FOnRing;
	Classes::TNotifyEvent FOnBreak;
	TVaCommErrorEvent FOnError;
	TVaCommRxCharEvent FOnRxChar;
	Classes::TNotifyEvent FOnRxFlag;
	TVaCommRxBufEvent FOnRxBuf;
	Classes::TNotifyEvent FOnTxEmpty;
	Classes::TNotifyEvent FOnPErr;
	Classes::TNotifyEvent FOnRx80Full;
	Classes::TNotifyEvent FOnEvent1;
	Classes::TNotifyEvent FOnEvent2;
	Vadisplay::TVaDisplay* FDisplay;
	bool __fastcall GetComStat(int Index);
	bool __fastcall GetModemStatus(int Index);
	_COMMPROP __fastcall GetProperties(void);
	void __fastcall SetBaudrate(TVaBaudrate Value);
	void __fastcall SetParity(TVaParity Value);
	void __fastcall SetDatabits(TVaDatabits Value);
	void __fastcall SetStopbits(TVaStopbits Value);
	void __fastcall SetOptions(TVaCommOptions Value);
	void __fastcall SetEventChars(Vaprst::TVaEventChars* Value);
	void __fastcall SetFlowControl(Vaprst::TVaFlowControl* Value);
	void __fastcall SetPortNum(Vatypes::TVaPortInt Value);
	void __fastcall SetMonitorEvents(TVaCommEvents Value);
	void __fastcall SetBuffers(Vaprst::TVaBuffers* Value);
	void __fastcall SetEventPriority(Classes::TThreadPriority Value);
	void __fastcall SetWritePriority(Classes::TThreadPriority Value);
	void __fastcall SetDirectWrite(bool Value);
	void __fastcall SetUpdateDCB(bool Value);
	void __fastcall SetDeviceName(const AnsiString Value);
	void __fastcall SetUserBaudrate(int Value);
	void __fastcall UpdateBuffers(void);
	void __fastcall UpdateTimeouts(void);
	void __fastcall UpdateEventMask(void);
	void __fastcall PurgeBuffers(int Mode);
	void __fastcall ToggleCommState(unsigned AState);
	void __fastcall BuffersChanged(System::TObject* Sender);
	void __fastcall EventCharsChanged(System::TObject* Sender);
	void __fastcall FlowControlChanged(System::TObject* Sender);
	void __fastcall UpdateDisplay(void);
	void __fastcall SetDisplay(const Vadisplay::TVaDisplay* Value);
	
protected:
	virtual void __fastcall Loaded(void);
	virtual void __fastcall CreateHandle(void);
	void __fastcall DestroyHandle(void);
	virtual void __fastcall CreateThreads(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	void __fastcall DestroyThreads(void);
	void __fastcall CheckOpen(void);
	void __fastcall DoOpen(void);
	void __fastcall DoClose(void);
	void __fastcall WriteLock(void);
	void __fastcall WriteUnlock(void);
	void __fastcall GlobalLock(void);
	void __fastcall GlobalUnlock(void);
	void __fastcall SetDCB(void);
	void __fastcall ReadDCB(const _DCB &DCB);
	void __fastcall Error(AnsiString Msg);
	void __fastcall Watch(bool B, AnsiString Msg);
	bool __fastcall ClearLineErrors(void);
	TVaCommStatus __fastcall GetCommStatus(void);
	AnsiString __fastcall GetDeviceName(void);
	virtual void __fastcall HandleDataEvent(void);
	virtual void __fastcall HandleLineEvent(unsigned EvtMask);
	void __fastcall DestroyClients(void);
	virtual void __fastcall WriteEvents(unsigned Events);
	virtual void __fastcall WriteBuffer(PVaData Data, int Count);
	__property bool AutoOpen = {read=FAutoOpen, write=FAutoOpen, default=0};
	__property TVaBaudrate Baudrate = {read=FBaudrate, write=SetBaudrate, default=4};
	__property TVaParity Parity = {read=FParity, write=SetParity, default=0};
	__property TVaDatabits Databits = {read=FDatabits, write=SetDatabits, default=4};
	__property TVaStopbits Stopbits = {read=FStopbits, write=SetStopbits, default=0};
	__property Vaprst::TVaEventChars* EventChars = {read=FEventChars, write=SetEventChars};
	__property Vaprst::TVaFlowControl* FlowControl = {read=FFlowControl, write=SetFlowControl};
	__property TVaCommOptions Options = {read=FOptions, write=SetOptions, default=0};
	__property Vatypes::TVaPortInt PortNum = {read=FPortNum, write=SetPortNum, default=0};
	__property AnsiString DeviceName = {read=FDeviceName, write=SetDeviceName};
	__property TVaCommEvents MonitorEvents = {read=FMonitorEvents, write=SetMonitorEvents, default=200}
		;
	__property Vaprst::TVaBuffers* Buffers = {read=FBuffers, write=SetBuffers};
	__property Classes::TThreadPriority EventPriority = {read=FEventPriority, write=SetEventPriority, default=3
		};
	__property Classes::TThreadPriority WritePriority = {read=FWritePriority, write=SetWritePriority, default=5
		};
	__property bool DirectWrite = {read=FDirectWrite, write=SetDirectWrite, default=0};
	__property bool UpdateDCB = {read=FUpdateDCB, write=SetUpdateDCB, default=1};
	__property int UserBaudrate = {read=FUserBaudrate, write=SetUserBaudrate, default=0};
	__property Classes::TNotifyEvent OnOpen = {read=FOnOpen, write=FOnOpen};
	__property Classes::TNotifyEvent OnClose = {read=FOnClose, write=FOnClose};
	__property Classes::TNotifyEvent OnCts = {read=FOnCts, write=FOnCts};
	__property Classes::TNotifyEvent OnDsr = {read=FOnDsr, write=FOnDsr};
	__property Classes::TNotifyEvent OnRlsd = {read=FOnRlsd, write=FOnRlsd};
	__property Classes::TNotifyEvent OnRing = {read=FOnRing, write=FOnRing};
	__property Classes::TNotifyEvent OnBreak = {read=FOnBreak, write=FOnBreak};
	__property TVaCommErrorEvent OnError = {read=FOnError, write=FOnError};
	__property TVaCommRxCharEvent OnRxChar = {read=FOnRxChar, write=FOnRxChar};
	__property TVaCommRxBufEvent OnRxBuf = {read=FOnRxBuf, write=FOnRxBuf};
	__property Classes::TNotifyEvent OnRxFlag = {read=FOnRxFlag, write=FOnRxFlag};
	__property Classes::TNotifyEvent OnTxEmpty = {read=FOnTxEmpty, write=FOnTxEmpty};
	__property Classes::TNotifyEvent OnPErr = {read=FOnPErr, write=FOnPErr};
	__property Classes::TNotifyEvent OnRx80Full = {read=FOnRx80Full, write=FOnRx80Full};
	__property Classes::TNotifyEvent OnEvent1 = {read=FOnEvent1, write=FOnEvent1};
	__property Classes::TNotifyEvent OnEvent2 = {read=FOnEvent2, write=FOnEvent2};
	
public:
	__fastcall virtual TVaCustomComm(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaCustomComm(void);
	void __fastcall Open(void);
	void __fastcall Close(void);
	bool __fastcall Active(void);
	void __fastcall InsertClient(TVaDispatcher* Value);
	void __fastcall RemoveClient(TVaDispatcher* Value);
	int __fastcall WriteBuf(void *Buf, int Count);
	bool __fastcall WriteText(const AnsiString s);
	bool __fastcall WriteChar(char Ch);
	int __fastcall ReadBuf(void *Buf, int Count);
	AnsiString __fastcall ReadText(void);
	bool __fastcall ReadChar(char &Ch);
	int __fastcall ReadBufFree(void);
	int __fastcall ReadBufUsed(void);
	int __fastcall WriteBufFree(void);
	int __fastcall WriteBufUsed(void);
	void __fastcall PurgeRead(void);
	void __fastcall PurgeWrite(void);
	void __fastcall PurgeReadWrite(void);
	void __fastcall SetDTR(bool Value);
	void __fastcall SetRTS(bool Value);
	void __fastcall SetXon(bool Value);
	void __fastcall SetBreak(bool Value);
	void __fastcall ResetDev(void);
	void __fastcall EnableControls(void);
	void __fastcall DisableControls(void);
	void __fastcall ResetPortParameters(void);
	void __fastcall GetComPortNames(Classes::TStringList* Value);
	__property unsigned Handle = {read=FHandle, nodefault};
	__property bool CTS = {read=GetModemStatus, index=1, nodefault};
	__property bool DSR = {read=GetModemStatus, index=2, nodefault};
	__property bool RING = {read=GetModemStatus, index=3, nodefault};
	__property bool RLSD = {read=GetModemStatus, index=4, nodefault};
	__property bool CTSHold = {read=GetComStat, index=1, nodefault};
	__property bool DSRHold = {read=GetComStat, index=2, nodefault};
	__property bool RLSDHold = {read=GetComStat, index=3, nodefault};
	__property bool XOffHold = {read=GetComStat, index=4, nodefault};
	__property bool XOffSent = {read=GetComStat, index=5, nodefault};
	__property _COMMPROP Properties = {read=GetProperties};
	__property Vadisplay::TVaDisplay* Display = {read=FDisplay, write=SetDisplay};
};

#pragma pack(pop)

#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaCommEventThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	unsigned FEvtMask;
	Vaobjects::TVaWaitEvent* FEvent;
	TVaCustomComm* FOwner;
	
protected:
	void __fastcall DoEvent(void);
	virtual void __fastcall Execute(void);
	void __fastcall StopThread(void);
	
public:
	__fastcall TVaCommEventThread(TVaCustomComm* AOwner);
	__fastcall virtual ~TVaCommEventThread(void);
};

#pragma pack(pop)

class DELPHICLASS TVaComm;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaComm : public TVaCustomComm 
{
	typedef TVaCustomComm inherited;
	
__published:
	__property AutoOpen ;
	__property Baudrate ;
	__property Parity ;
	__property Databits ;
	__property Stopbits ;
	__property EventChars ;
	__property FlowControl ;
	__property Options ;
	__property PortNum ;
	__property DeviceName ;
	__property MonitorEvents ;
	__property Buffers ;
	__property EventPriority ;
	__property WritePriority ;
	__property DirectWrite ;
	__property UpdateDCB ;
	__property UserBaudrate ;
	__property OnOpen ;
	__property OnClose ;
	__property OnCts ;
	__property OnDsr ;
	__property OnRlsd ;
	__property OnRing ;
	__property OnBreak ;
	__property OnError ;
	__property OnRxChar ;
	__property OnRxBuf ;
	__property OnRxFlag ;
	__property OnTxEmpty ;
	__property OnPErr ;
	__property OnRx80Full ;
	__property OnEvent1 ;
	__property OnEvent2 ;
	__property Display ;
public:
	#pragma option push -w-inl
	/* TVaCustomComm.Create */ inline __fastcall virtual TVaComm(Classes::TComponent* AOwner) : TVaCustomComm(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TVaCustomComm.Destroy */ inline __fastcall virtual ~TVaComm(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

__interface IVaCommUser;
typedef System::DelphiInterface<IVaCommUser> _di_IVaCommUser;
__interface IVaCommUser  : public IUnknown 
{
	
public:
	virtual void __fastcall LineChanged(unsigned Events) = 0 ;
	virtual void __fastcall DataChanged(PVaData Data, int Count) = 0 ;
};

#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaDispatcher : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	bool FActive;
	TVaCustomComm* FComm;
	_di_IVaCommUser FOwner;
	void __fastcall LineEvent(unsigned Events);
	void __fastcall DataEvent(PVaData Data, int Count);
	
public:
	__fastcall TVaDispatcher(_di_IVaCommUser AOwner);
	__fastcall virtual ~TVaDispatcher(void);
	void __fastcall PurgeRead(void);
	void __fastcall PurgeWrite(void);
	void __fastcall PurgeReadWrite(void);
	int __fastcall WriteBuf(void *Buf, int Count);
	bool __fastcall WriteText(const AnsiString s);
	bool __fastcall WriteChar(char Ch);
	void __fastcall SetDTRState(bool Value);
	__property bool Active = {read=FActive, write=FActive, nodefault};
	__property TVaCustomComm* Comm = {read=FComm, write=FComm};
};

#pragma pack(pop)

class DELPHICLASS TVaCommComponent;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVaCommComponent : public Vaclasses::TVaComponent 
{
	typedef Vaclasses::TVaComponent inherited;
	
private:
	TVaComm* FComm;
	TVaDispatcher* FDispatcher;
	bool __fastcall GetActive(void);
	void __fastcall SetActive(bool Value);
	void __fastcall SetComm(TVaComm* Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	virtual void __fastcall DataChanged(PVaData Data, int Count);
	virtual void __fastcall LineChanged(unsigned Events);
	__property bool Active = {read=GetActive, write=SetActive, nodefault};
	
public:
	__fastcall virtual TVaCommComponent(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaCommComponent(void);
	__property TVaDispatcher* Dispatcher = {read=FDispatcher};
	
__published:
	__property TVaComm* Comm = {read=FComm, write=SetComm};
private:
	void *__IVaCommUser;	/* Vacomm::IVaCommUser */
	
public:
	operator IVaCommUser*(void) { return (IVaCommUser*)&__IVaCommUser; }
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vacomm */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vacomm;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaComm
