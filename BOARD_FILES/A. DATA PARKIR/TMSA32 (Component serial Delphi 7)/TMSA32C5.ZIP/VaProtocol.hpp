// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaProtocol.pas' rev: 5.00

#ifndef VaProtocolHPP
#define VaProtocolHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaObjects.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vaprotocol
{
//-- type declarations -------------------------------------------------------
typedef Exception EProtAbort;
;

#pragma option push -b-
enum TVaTransferMode { tmUpload, tmDownload };
#pragma option pop

typedef void __fastcall (__closure *TVaTransferEndEvent)(System::TObject* Sender, int ExitCode);

typedef void __fastcall (__closure *TVaTransferErrorEvent)(System::TObject* Sender, int ErrorCode, int 
	ErrorCount);

typedef void __fastcall (__closure *TVaPacketEvent)(System::TObject* Sender, int Packet, int ByteCount
	);

typedef void __fastcall (__closure *TVaFileInfoEvent)(System::TObject* Sender, const AnsiString Name
	, int Size);

class DELPHICLASS TVaProtocolThread;
class DELPHICLASS TVaProtocol;
class PASCALIMPLEMENTATION TVaProtocol : public Vacomm::TVaCommComponent 
{
	typedef Vacomm::TVaCommComponent inherited;
	
private:
	TVaProtocolThread* FThread;
	int FTimeout;
	TVaTransferMode FMode;
	int FExitCode;
	int FMaxErrors;
	int FBufferSize;
	Classes::TNotifyEvent FOnTransferStart;
	TVaTransferEndEvent FOnTransferEnd;
	TVaTransferErrorEvent FOnError;
	int __fastcall GetErrorCode(void);
	int __fastcall GetErrorCount(void);
	bool __fastcall GetIsActive(void);
	void __fastcall CheckActive(void);
	void __fastcall Terminate(System::TObject* Sender);
	
protected:
	virtual TVaProtocolThread* __fastcall CreateThread(void) = 0 ;
	virtual void __fastcall DataChanged(Vacomm::PVaData Data, int Count);
	virtual void __fastcall TransferStart(void);
	virtual void __fastcall TransferEnd(void);
	void __fastcall ErrorEvent(void);
	void __fastcall SetExitCode(int Value);
	virtual void __fastcall Initialize(void);
	__property int ExitCode = {read=FExitCode, nodefault};
	
public:
	__fastcall virtual TVaProtocol(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaProtocol(void);
	virtual void __fastcall Execute(void);
	virtual void __fastcall Cancel(void);
	__property int ErrorCode = {read=GetErrorCode, nodefault};
	__property int ErrorCount = {read=GetErrorCount, nodefault};
	__property bool IsActive = {read=GetIsActive, nodefault};
	
__published:
	__property TVaTransferMode Mode = {read=FMode, write=FMode, nodefault};
	__property int Timeout = {read=FTimeout, write=FTimeout, default=60000};
	__property int MaxErrors = {read=FMaxErrors, write=FMaxErrors, default=10};
	__property int BufferSize = {read=FBufferSize, write=FBufferSize, default=4096};
	__property Classes::TNotifyEvent OnTransferStart = {read=FOnTransferStart, write=FOnTransferStart};
		
	__property TVaTransferEndEvent OnTransferEnd = {read=FOnTransferEnd, write=FOnTransferEnd};
	__property TVaTransferErrorEvent OnError = {read=FOnError, write=FOnError};
};


class PASCALIMPLEMENTATION TVaProtocolThread : public Classes::TThread 
{
	typedef Classes::TThread inherited;
	
private:
	Vacomm::TVaCommBuffer* FBuffer;
	Classes::TFileStream* FStream;
	int FErrorCode;
	int FErrorCount;
	bool FAbortTransfer;
	bool FBufferOverrun;
	Vaobjects::TVaCriticalSection* FCriticalSection;
	Vaobjects::TVaWaitEvent* FTimeEvent;
	TVaProtocol* FOwner;
	
protected:
	void __fastcall Lock(void);
	void __fastcall Unlock(void);
	virtual int __fastcall ReadChar(void);
	int __fastcall PeekChar(void);
	bool __fastcall CharReceived(void);
	void __fastcall PutBuf(void *Buf, int Count);
	void __fastcall WriteBuf(void *Buf, int Count);
	void __fastcall WriteChar(Byte aByte);
	virtual void __fastcall Upload(void) = 0 ;
	virtual void __fastcall Download(void) = 0 ;
	virtual void __fastcall Initialize(void);
	void __fastcall OpenStream(AnsiString FileName);
	void __fastcall CreateStream(AnsiString FileName);
	void __fastcall CloseStream(void);
	bool __fastcall EndOfStream(void);
	void __fastcall SetExitCode(int Value);
	virtual void __fastcall RemoteCan(void);
	void __fastcall DoError(void);
	void __fastcall ErrorEvent(int ErrorCode, bool RCan);
	__property Classes::TFileStream* Stream = {read=FStream, write=FStream};
	__property TVaProtocol* Owner = {read=FOwner};
	__property bool AbortTransfer = {read=FAbortTransfer, nodefault};
	
public:
	__fastcall TVaProtocolThread(TVaProtocol* AOwner);
	__fastcall virtual ~TVaProtocolThread(void);
	void __fastcall Cancel(void);
	virtual void __fastcall Execute(void);
	HIDESBASE void __fastcall Terminate(void);
	__property int ErrorCode = {read=FErrorCode, nodefault};
	__property int ErrorCount = {read=FErrorCount, nodefault};
};


typedef Byte TVaPacket[1024];

class DELPHICLASS TVaXYModemThread;
class PASCALIMPLEMENTATION TVaXYModemThread : public TVaProtocolThread 
{
	typedef TVaProtocolThread inherited;
	
private:
	Byte FPacket[1024];
	int FPacketNum;
	int FByteCount;
	AnsiString FFileName;
	int FFileSize;
	void __fastcall FileInfo(AnsiString Name, int Size);
	void __fastcall PacketEvent(int Packet, int Bytes);
	
protected:
	virtual void __fastcall RemoteCan(void);
	void __fastcall RemoteTxStartup(Byte &NCGByte);
	void __fastcall RemoteRxStartup(Byte NCGByte);
	void __fastcall ResetPacket(void);
	void __fastcall ReadPacket(int PacketNum, int &PacketSize, Byte NCGByte);
	void __fastcall ReadFile(AnsiString Name, int Size, Byte NCGByte);
	void __fastcall WriteEOT(void);
	void __fastcall WritePacket(int PacketNum, int PacketSize, Byte NCGByte);
	void __fastcall WriteFile(AnsiString Name);
	__property int PacketNum = {read=FPacketNum, nodefault};
	__property int ByteCount = {read=FByteCount, nodefault};
	__property AnsiString FileName = {read=FFileName};
	__property int FileSize = {read=FFileSize, nodefault};
public:
	#pragma option push -w-inl
	/* TVaProtocolThread.Create */ inline __fastcall TVaXYModemThread(TVaProtocol* AOwner) : TVaProtocolThread(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TVaProtocolThread.Destroy */ inline __fastcall virtual ~TVaXYModemThread(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaXYModem;
class PASCALIMPLEMENTATION TVaXYModem : public TVaProtocol 
{
	typedef TVaProtocol inherited;
	
private:
	TVaFileInfoEvent FOnFileInfo;
	TVaPacketEvent FOnPacketEvent;
	
protected:
	void __fastcall FileInfo(void);
	void __fastcall PacketEvent(void);
	
__published:
	__property TVaFileInfoEvent OnFileInfo = {read=FOnFileInfo, write=FOnFileInfo};
	__property TVaPacketEvent OnPacketEvent = {read=FOnPacketEvent, write=FOnPacketEvent};
public:
	#pragma option push -w-inl
	/* TVaProtocol.Create */ inline __fastcall virtual TVaXYModem(Classes::TComponent* AOwner) : TVaProtocol(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TVaProtocol.Destroy */ inline __fastcall virtual ~TVaXYModem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaXModemThread;
class PASCALIMPLEMENTATION TVaXModemThread : public TVaXYModemThread 
{
	typedef TVaXYModemThread inherited;
	
protected:
	virtual void __fastcall Upload(void);
	virtual void __fastcall Download(void);
public:
	#pragma option push -w-inl
	/* TVaProtocolThread.Create */ inline __fastcall TVaXModemThread(TVaProtocol* AOwner) : TVaXYModemThread(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TVaProtocolThread.Destroy */ inline __fastcall virtual ~TVaXModemThread(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TVaXProtocol { XModem, XModem1K, XModemG };
#pragma option pop

class DELPHICLASS TVaXModem;
class PASCALIMPLEMENTATION TVaXModem : public TVaXYModem 
{
	typedef TVaXYModem inherited;
	
private:
	AnsiString FFileName;
	TVaXProtocol FProtocol;
	
protected:
	virtual TVaProtocolThread* __fastcall CreateThread(void);
	
public:
	__fastcall virtual TVaXModem(Classes::TComponent* AOwner);
	
__published:
	__property AnsiString FileName = {read=FFileName, write=FFileName};
	__property TVaXProtocol Protocol = {read=FProtocol, write=FProtocol, nodefault};
public:
	#pragma option push -w-inl
	/* TVaProtocol.Destroy */ inline __fastcall virtual ~TVaXModem(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaYModemThread;
class PASCALIMPLEMENTATION TVaYModemThread : public TVaXYModemThread 
{
	typedef TVaXYModemThread inherited;
	
private:
	Classes::TStrings* __fastcall GetFiles(void);
	
protected:
	virtual void __fastcall Upload(void);
	virtual void __fastcall Download(void);
	__property Classes::TStrings* Files = {read=GetFiles};
public:
	#pragma option push -w-inl
	/* TVaProtocolThread.Create */ inline __fastcall TVaYModemThread(TVaProtocol* AOwner) : TVaXYModemThread(
		AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TVaProtocolThread.Destroy */ inline __fastcall virtual ~TVaYModemThread(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TVaYProtocol { YModem, YModemG };
#pragma option pop

class DELPHICLASS TVaYModem;
class PASCALIMPLEMENTATION TVaYModem : public TVaXYModem 
{
	typedef TVaXYModem inherited;
	
private:
	Classes::TStrings* FFiles;
	AnsiString FTargetFolder;
	TVaYProtocol FProtocol;
	void __fastcall SetFiles(Classes::TStrings* Value);
	
protected:
	virtual TVaProtocolThread* __fastcall CreateThread(void);
	
public:
	__fastcall virtual TVaYModem(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaYModem(void);
	
__published:
	__property Classes::TStrings* Files = {read=FFiles, write=SetFiles};
	__property TVaYProtocol Protocol = {read=FProtocol, write=FProtocol, nodefault};
	__property AnsiString TargetFolder = {read=FTargetFolder, write=FTargetFolder};
};


//-- var, const, procedure ---------------------------------------------------
static const Word MAX_RXSIZE = 0x1000;
static const Word MAX_PACKET = 0x400;
static const Shortint ErrorNone = 0x0;
static const Shortint ErrorTimeout = 0xffffffff;
static const Shortint ErrorLocalCan = 0xfffffffd;
static const Shortint ErrorRemoteCan = 0xfffffffc;
static const Shortint ErrorOutOfSync = 0xfffffffb;
static const Shortint ErrorStreamRead = 0xfffffff9;
static const Shortint ErrorStreamWrite = 0xfffffff8;
static const Shortint ErrorMaxErrors = 0xfffffff7;
static const Shortint ErrorRemoteStartup = 0xfffffff6;
static const Shortint ErrorFileCreate = 0xfffffff5;
static const Shortint ErrorFileOpen = 0xfffffff4;
static const Shortint ErrorBufferOverrun = 0xfffffff2;
static const Shortint ErrorInvalidPacket = 0xfffffff1;
static const Shortint ErrorInvalidChar = 0xfffffff0;
static const Shortint ErrorStreamSeek = 0xffffffef;
static const Shortint ErrorUnknownHeader = 0xffffffed;
static const Shortint ErrorRepeatHeader = 0xffffffec;
static const Shortint ErrorRemoteFileErr = 0xffffffeb;
static const Shortint ErrorProgramExit = 0xffffffea;
static const Shortint ErrorPacketToLarge = 0xffffffe9;
static const Shortint ErrorRemoteShutdown = 0xffffffe8;
static const Shortint ErrorZCommand = 0xffffffe7;
static const Shortint RX0 = 0x0;
static const Shortint SOH = 0x1;
static const Shortint STX = 0x2;
static const Shortint EOT = 0x4;
static const Shortint ACK = 0x6;
static const Shortint NAK = 0x15;
static const Shortint CAN = 0x18;
static const Shortint XYN = 0x15;
static const Byte XYC = 0x43;
static const Byte XYG = 0x47;

}	/* namespace Vaprotocol */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vaprotocol;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaProtocol
