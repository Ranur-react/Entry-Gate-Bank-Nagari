// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaZmodem.pas' rev: 5.00

#ifndef VaZmodemHPP
#define VaZmodemHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaCrc32.hpp>	// Pascal unit
#include <VaProtocol.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vazmodem
{
//-- type declarations -------------------------------------------------------
typedef Byte zHdrType[4];

typedef Byte zBufType[1024];

typedef void __fastcall (__closure *TVaFileProgressEvent)(System::TObject* Sender, int ByteCount);

class DELPHICLASS TVaZModemThread;
class PASCALIMPLEMENTATION TVaZModemThread : public Vaprotocol::TVaProtocolThread 
{
	typedef Vaprotocol::TVaProtocolThread inherited;
	
private:
	Byte FData[1024];
	Byte FAttn[1024];
	Byte FLastsent;
	bool FUseCRC32;
	int FRxBufSize;
	bool FFrameCRCW;
	bool FCanResume;
	bool FGotZSInit;
	AnsiString FRxFileName;
	int FRxFileSize;
	int FRxFileTime;
	AnsiString FFileName;
	int FFileSize;
	int FByteCount;
	Classes::TStrings* __fastcall GetFiles(void);
	
protected:
	void __fastcall FileInfoEvent(void);
	void __fastcall FileInfo(AnsiString Name, int Size);
	void __fastcall FileProgressEvent(void);
	void __fastcall FileProgress(int ByteCount);
	virtual void __fastcall Initialize(void);
	virtual int __fastcall ReadChar(void);
	unsigned __fastcall LongintFromHeader(Byte * Hdr);
	void __fastcall LongintToHeader(unsigned Value, Byte * Hdr);
	int __fastcall ReadZChar(void);
	void __fastcall PutString(Byte * Buf);
	void __fastcall WriteZByte(Byte aByte);
	void __fastcall WriteHex(Byte aByte);
	void __fastcall WriteHexHeader(Byte HType, Byte * Header);
	void __fastcall WriteBinaryHeader32(Byte HType, Byte * Header);
	void __fastcall WriteBinaryHeader(Byte HType, Byte * Header);
	int __fastcall ReadHex(void);
	virtual void __fastcall RemoteCan(void);
	int __fastcall GetZDLE(void);
	int __fastcall ReadHexHeader(Byte * Hdr);
	int __fastcall ReadBinaryHeader16(Byte * Hdr);
	int __fastcall ReadBinaryHeader32(Byte * Hdr);
	int __fastcall ReadHeader(Byte * hdr);
	void __fastcall WriteEot(void);
	void __fastcall RemoteStartup(void);
	void __fastcall SyncWithReceiver(void);
	void __fastcall WriteData32(Byte * Buf, int ByteCount, Byte FrameEnd);
	void __fastcall WriteData(Byte * Buf, int ByteCount, Byte FrameEnd);
	void __fastcall NewFilePos(const Byte * Header);
	void __fastcall WriteFile(AnsiString FileName);
	void __fastcall ReceiveStartup(void);
	void __fastcall ReceiveConfirm(void);
	void __fastcall ReceiveCommand(void);
	int __fastcall ReadData32(Byte * Buf, int ByteCount, int &BytesReceived);
	int __fastcall ReadData(Byte * Buf, int ByteCount, int &BytesReceived);
	void __fastcall ExtractFileInfo(void);
	AnsiString __fastcall ReadFile(AnsiString Folder);
	virtual void __fastcall Upload(void);
	virtual void __fastcall Download(void);
	__property Classes::TStrings* Files = {read=GetFiles};
public:
	#pragma option push -w-inl
	/* TVaProtocolThread.Create */ inline __fastcall TVaZModemThread(Vaprotocol::TVaProtocol* AOwner) : 
		Vaprotocol::TVaProtocolThread(AOwner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TVaProtocolThread.Destroy */ inline __fastcall virtual ~TVaZModemThread(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaZModem;
class PASCALIMPLEMENTATION TVaZModem : public Vaprotocol::TVaProtocol 
{
	typedef Vaprotocol::TVaProtocol inherited;
	
private:
	Classes::TStrings* FFiles;
	AnsiString FTargetFolder;
	Vaprotocol::TVaFileInfoEvent FOnFileInfo;
	TVaFileProgressEvent FOnFileProgress;
	void __fastcall SetFiles(Classes::TStrings* Value);
	
protected:
	void __fastcall FileInfo(AnsiString Name, int Size);
	void __fastcall FileProgress(int ByteCount);
	virtual Vaprotocol::TVaProtocolThread* __fastcall CreateThread(void);
	
public:
	__fastcall virtual TVaZModem(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaZModem(void);
	
__published:
	__property Classes::TStrings* Files = {read=FFiles, write=SetFiles};
	__property AnsiString TargetFolder = {read=FTargetFolder, write=FTargetFolder};
	__property Vaprotocol::TVaFileInfoEvent OnFileInfo = {read=FOnFileInfo, write=FOnFileInfo};
	__property TVaFileProgressEvent OnFileProgress = {read=FOnFileProgress, write=FOnFileProgress};
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE System::TDateTime __fastcall GMTtoPACKT(int GMT);
extern PACKAGE System::TDateTime __fastcall Zfromunixdate(AnsiString S);

}	/* namespace Vazmodem */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vazmodem;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaZmodem
