// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaConst.pas' rev: 5.00

#ifndef VaConstHPP
#define VaConstHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vaconst
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
#define crlf "\r\n"
#define sCE_BREAK "The hardware detected a break condition."
#define sCE_DNS "Windows 95 only: A parallel device is not selected."
#define sCE_FRAME "The hardware detected a framing error."
#define sCE_IOE "An I/O error occurred during communications with the devic"\
	"e."
#define sCE_MODE "The requested mode is not supported."
#define sCE_OOP "Windows 95 only: A parallel device signaled that it is out"\
	" of paper."
#define sCE_OVERRUN "A character-buffer overrun has occurred. The next characte"\
	"r is lost."
#define sCE_PTO "Windows 95 only: A time-out occurred on a parallel device."\
	""
#define sCE_RXOVER "An input buffer overflow has occurred."
#define sCE_RXPARITY "The hardware detected a parity error."
#define sCE_TXFULL "Transmit buffer overflow."
static const Shortint cPurgeRead = 0xa;
static const Shortint cPurgeWrite = 0x5;
static const Shortint cPurgeReadWrite = 0xf;
static const Shortint fBinary = 0x1;
static const Shortint fParity = 0x2;
static const Shortint fOutxCtsFlow = 0x4;
static const Shortint fOutxDsrFlow = 0x8;
static const Shortint fDtrControl = 0x30;
static const Shortint fDtrControlDisable = 0x0;
static const Shortint fDtrControlEnable = 0x10;
static const Shortint fDtrControlHandshake = 0x20;
static const Shortint fDsrSensitivity = 0x40;
static const Byte fTXContinueOnXoff = 0x80;
static const Word fOutX = 0x100;
static const Word fInX = 0x200;
static const Word fErrorChar = 0x400;
static const Word fNull = 0x800;
static const Word fRtsControl = 0x3000;
static const Shortint fRtsControlDisable = 0x0;
static const Word fRtsControlEnable = 0x1000;
static const Word fRtsControlHandshake = 0x2000;
static const Word fRtsControlToggle = 0x3000;
static const Word fAbortOnError = 0x4000;

}	/* namespace Vaconst */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Vaconst;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaConst
