// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaUtils.pas' rev: 6.00

#ifndef VaUtilsHPP
#define VaUtilsHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaConst.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vautils
{
//-- type declarations -------------------------------------------------------
#pragma pack(push, 4)
struct TVaTimeEvent
{
	unsigned Ticks;
	unsigned Delay;
} ;
#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
static const Shortint PS_OPEN = 0x0;
static const Shortint PS_CLOSE = 0x1;
static const Shortint PS_NOTEXIST = 0x2;
extern PACKAGE int __fastcall MinInteger(int A, int B);
extern PACKAGE char __fastcall CN(char Ch);
extern PACKAGE void __fastcall InitTimer(TVaTimeEvent &TimeEvent, int MsDelay);
extern PACKAGE bool __fastcall TimerExpired(const TVaTimeEvent &TimeEvent);
extern PACKAGE void __fastcall SysDelay(int MsDelay, bool Yield);
extern PACKAGE int __fastcall GetPortState(int PortNumber);
extern PACKAGE bool __fastcall BitOn(int Value, int Bit);
extern PACKAGE bool __fastcall BitOff(int Value, int Bit);
extern PACKAGE AnsiString __fastcall StrCtrl(AnsiString Value);
extern PACKAGE void __fastcall FreeObject(void *Obj);
extern PACKAGE AnsiString __fastcall AddPathSlash(AnsiString Path);
extern PACKAGE int __fastcall GetFileSize(const AnsiString FileName);
extern PACKAGE AnsiString __fastcall CreateUniqueFileName(AnsiString FileName);

}	/* namespace Vautils */
using namespace Vautils;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaUtils
