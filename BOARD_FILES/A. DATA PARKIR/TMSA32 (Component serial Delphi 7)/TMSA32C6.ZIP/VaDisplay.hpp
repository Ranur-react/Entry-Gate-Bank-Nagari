// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaDisplay.pas' rev: 6.00

#ifndef VaDisplayHPP
#define VaDisplayHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaControls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vadisplay
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TVrDisplayType { ltRounded, ltRectangle };
#pragma option pop

#pragma option push -b-
enum TVrDisplayMode { ltHide, ltScale };
#pragma option pop

class DELPHICLASS TVaDisplay;
class PASCALIMPLEMENTATION TVaDisplay : public Vacontrols::TVaGraphicControl 
{
	typedef Vacontrols::TVaGraphicControl inherited;
	
public:
	virtual void __fastcall UpdateDisplay(Classes::TComponent* AOwner) = 0 ;
public:
	#pragma option push -w-inl
	/* TVaGraphicControl.Create */ inline __fastcall virtual TVaDisplay(Classes::TComponent* AOwner) : Vacontrols::TVaGraphicControl(AOwner) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TGraphicControl.Destroy */ inline __fastcall virtual ~TVaDisplay(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaLEDDisplay;
class PASCALIMPLEMENTATION TVaLEDDisplay : public TVaDisplay 
{
	typedef TVaDisplay inherited;
	
private:
	bool FShowCTS;
	bool FShowDSR;
	bool FShowXOffHold;
	bool FShowRLSD;
	bool FShowRLSDHold;
	bool FShowXOffSent;
	bool FShowRING;
	bool FShowCTSHold;
	bool FShowDSRHold;
	Graphics::TColor FOnColor;
	Graphics::TColor FOffColor;
	TVrDisplayType FDisplayType;
	TVrDisplayMode FDisplayMode;
	bool FDisplaycaption;
	Graphics::TBitmap* FLEDImage;
	void __fastcall SetOffColor(const Graphics::TColor Value);
	void __fastcall SetOnColor(const Graphics::TColor Value);
	void __fastcall SetShowCTS(const bool Value);
	void __fastcall SetShowCTSHold(const bool Value);
	void __fastcall SetShowDSR(const bool Value);
	void __fastcall SetShowDSRHold(const bool Value);
	void __fastcall SetShowRING(const bool Value);
	void __fastcall SetShowRLSD(const bool Value);
	void __fastcall SetShowRLSDHold(const bool Value);
	void __fastcall SetShowXOffHold(const bool Value);
	void __fastcall SetShowXOffSent(const bool Value);
	void __fastcall SetDisplayType(const TVrDisplayType Value);
	void __fastcall SetDisplayMode(const TVrDisplayMode Value);
	void __fastcall SetDisplaycaption(const bool Value);
	
protected:
	bool LastCTS;
	bool LastDSR;
	bool LastRING;
	bool LastRLSD;
	bool LastCTSHold;
	bool LastDSRHold;
	bool LastRLSDHold;
	bool LastXOffHold;
	bool LastXOffSent;
	int visibleLeds;
	void __fastcall DrawALed(int LedLeft, int Ledwidth, Graphics::TColor color, AnsiString Caption);
	void __fastcall DoALed(int &LedLeft, int Ledwidth, bool Active, AnsiString Caption);
	void __fastcall DoAllLed(int &LedLeft, int Ledwidth);
	int __fastcall GetLedWidth(void);
	
public:
	__fastcall virtual TVaLEDDisplay(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaLEDDisplay(void);
	virtual void __fastcall UpdateDisplay(Classes::TComponent* AOwner);
	virtual void __fastcall Paint(void);
	virtual void __fastcall SetBounds(int ALeft, int ATop, int AWidth, int AHeight);
	
__published:
	__property Color  = {default=-2147483643};
	__property bool ShowCTS = {read=FShowCTS, write=SetShowCTS, default=1};
	__property bool ShowDSR = {read=FShowDSR, write=SetShowDSR, default=1};
	__property bool ShowRING = {read=FShowRING, write=SetShowRING, default=1};
	__property bool ShowRLSD = {read=FShowRLSD, write=SetShowRLSD, default=1};
	__property bool ShowCTSHold = {read=FShowCTSHold, write=SetShowCTSHold, default=1};
	__property bool ShowDSRHold = {read=FShowDSRHold, write=SetShowDSRHold, default=1};
	__property bool ShowRLSDHold = {read=FShowRLSDHold, write=SetShowRLSDHold, default=1};
	__property bool ShowXOffHold = {read=FShowXOffHold, write=SetShowXOffHold, default=1};
	__property bool ShowXOffSent = {read=FShowXOffSent, write=SetShowXOffSent, default=1};
	__property Graphics::TColor OnColor = {read=FOnColor, write=SetOnColor, default=16711680};
	__property Graphics::TColor OffColor = {read=FOffColor, write=SetOffColor, default=8388608};
	__property TVrDisplayType DisplayType = {read=FDisplayType, write=SetDisplayType, default=0};
	__property TVrDisplayMode DisplayMode = {read=FDisplayMode, write=SetDisplayMode, default=1};
	__property bool Displaycaption = {read=FDisplaycaption, write=SetDisplaycaption, default=1};
	__property Font ;
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vadisplay */
using namespace Vadisplay;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaDisplay
