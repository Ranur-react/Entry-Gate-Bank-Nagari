// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaReg.pas' rev: 6.00

#ifndef VaRegHPP
#define VaRegHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaANSIEmulation.hpp>	// Pascal unit
#include <VaTerminal.hpp>	// Pascal unit
#include <VaDisplay.hpp>	// Pascal unit
#include <VaZmodem.hpp>	// Pascal unit
#include <VaProtocol.hpp>	// Pascal unit
#include <VaModem.hpp>	// Pascal unit
#include <VaTriggers.hpp>	// Pascal unit
#include <VaServer.hpp>	// Pascal unit
#include <VaBuffer.hpp>	// Pascal unit
#include <VaSystem.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vareg
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Vareg */
using namespace Vareg;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaReg
