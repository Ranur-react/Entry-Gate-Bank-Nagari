// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaPrst.pas' rev: 6.00

#ifndef VaPrstHPP
#define VaPrstHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <VaUtils.hpp>	// Pascal unit
#include <VaObjects.hpp>	// Pascal unit
#include <VaClasses.hpp>	// Pascal unit
#include <VaTypes.hpp>	// Pascal unit
#include <VaConst.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vaprst
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TVaControlDtr { dtrDisabled, dtrEnabled, dtrHandshake };
#pragma option pop

#pragma option push -b-
enum TVaControlRts { rtsDisabled, rtsEnabled, rtsHandshake, rtsToggle };
#pragma option pop

class DELPHICLASS TVaFlowControl;
class PASCALIMPLEMENTATION TVaFlowControl : public Vaclasses::TVaPersistent 
{
	typedef Vaclasses::TVaPersistent inherited;
	
private:
	bool FOutCtsFlow;
	bool FOutDsrFlow;
	TVaControlDtr FControlDtr;
	TVaControlRts FControlRts;
	bool FXonXoffOut;
	bool FXonXoffIn;
	bool FDsrSensitivity;
	bool FTxContinueOnXoff;
	void __fastcall SetOutCtsFlow(bool Value);
	void __fastcall SetOutDsrFlow(bool Value);
	void __fastcall SetControlDtr(TVaControlDtr Value);
	void __fastcall SetControlRts(TVaControlRts Value);
	void __fastcall SetXonXoffOut(bool Value);
	void __fastcall SetXonXoffIn(bool Value);
	void __fastcall SetDsrSensitivity(bool Value);
	void __fastcall SetTxContinueOnXoff(bool Value);
	
public:
	__fastcall TVaFlowControl(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property bool OutCtsFlow = {read=FOutCtsFlow, write=SetOutCtsFlow, nodefault};
	__property bool OutDsrFlow = {read=FOutDsrFlow, write=SetOutDsrFlow, nodefault};
	__property TVaControlDtr ControlDtr = {read=FControlDtr, write=SetControlDtr, nodefault};
	__property TVaControlRts ControlRts = {read=FControlRts, write=SetControlRts, nodefault};
	__property bool XonXoffOut = {read=FXonXoffOut, write=SetXonXoffOut, nodefault};
	__property bool XonXoffIn = {read=FXonXoffIn, write=SetXonXoffIn, nodefault};
	__property bool DsrSensitivity = {read=FDsrSensitivity, write=SetDsrSensitivity, nodefault};
	__property bool TxContinueOnXoff = {read=FTxContinueOnXoff, write=SetTxContinueOnXoff, nodefault};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TVaFlowControl(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaEventChars;
class PASCALIMPLEMENTATION TVaEventChars : public Vaclasses::TVaPersistent 
{
	typedef Vaclasses::TVaPersistent inherited;
	
private:
	char FXonChar;
	char FXoffChar;
	char FErrorChar;
	char FEventChar;
	char FEofChar;
	void __fastcall SetEventChar(int Index, char Value);
	
public:
	__fastcall TVaEventChars(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property char XonChar = {read=FXonChar, write=SetEventChar, index=1, default=17};
	__property char XoffChar = {read=FXoffChar, write=SetEventChar, index=2, default=19};
	__property char ErrorChar = {read=FErrorChar, write=SetEventChar, index=3, default=0};
	__property char EventChar = {read=FEventChar, write=SetEventChar, index=4, default=0};
	__property char EofChar = {read=FEventChar, write=SetEventChar, index=5, default=0};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TVaEventChars(void) { }
	#pragma option pop
	
};


class DELPHICLASS TVaBuffers;
class PASCALIMPLEMENTATION TVaBuffers : public Vaclasses::TVaPersistent 
{
	typedef Vaclasses::TVaPersistent inherited;
	
private:
	Vatypes::TVaIntW FReadSize;
	Vatypes::TVaIntW FWriteSize;
	Vatypes::TVaIntW FReadTimeout;
	Vatypes::TVaIntW FWriteTimeout;
	Vatypes::TVaIntW FXonLimit;
	Vatypes::TVaIntW FXoffLimit;
	void __fastcall SetReadSize(Vatypes::TVaIntW Value);
	void __fastcall SetWriteSize(Vatypes::TVaIntW Value);
	void __fastcall SetXonLimit(Vatypes::TVaIntW Value);
	void __fastcall SetXoffLimit(Vatypes::TVaIntW Value);
	
public:
	__fastcall TVaBuffers(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property Vatypes::TVaIntW ReadSize = {read=FReadSize, write=SetReadSize, default=4096};
	__property Vatypes::TVaIntW WriteSize = {read=FWriteSize, write=SetWriteSize, default=2048};
	__property Vatypes::TVaIntW ReadTimeout = {read=FReadTimeout, write=FReadTimeout, default=1000};
	__property Vatypes::TVaIntW WriteTimeout = {read=FWriteTimeout, write=FWriteTimeout, default=1000};
	__property Vatypes::TVaIntW XonLimit = {read=FXonLimit, write=SetXonLimit, default=1024};
	__property Vatypes::TVaIntW XoffLimit = {read=FXoffLimit, write=SetXoffLimit, default=1024};
public:
	#pragma option push -w-inl
	/* TPersistent.Destroy */ inline __fastcall virtual ~TVaBuffers(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Vaprst */
using namespace Vaprst;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaPrst
