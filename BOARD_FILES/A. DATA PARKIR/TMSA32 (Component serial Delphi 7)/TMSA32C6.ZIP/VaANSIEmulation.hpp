// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VaANSIEmulation.pas' rev: 6.00

#ifndef VaANSIEmulationHPP
#define VaANSIEmulationHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Graphics.hpp>	// Pascal unit
#include <VaComm.hpp>	// Pascal unit
#include <VaTerminal.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Vaansiemulation
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TVaANSIEmulation;
class PASCALIMPLEMENTATION TVaANSIEmulation : public Vaterminal::IVaTerminalEmulation 
{
	typedef Vaterminal::IVaTerminalEmulation inherited;
	
private:
	char FLastChar;
	AnsiString FLastCommand;
	Graphics::TColor FLastColor;
	Graphics::TColor FLastBkg;
	bool FCommandMode;
	
public:
	__fastcall virtual TVaANSIEmulation(Classes::TComponent* AOwner);
	__fastcall virtual ~TVaANSIEmulation(void);
	virtual void __fastcall DataArrived(Vacomm::PVaData Data, int Count);
	virtual void __fastcall KeyDown(Word &Key, Classes::TShiftState Shift);
	virtual void __fastcall KeyPress(char &Key);
	virtual void __fastcall KeyUp(Word &Key, Classes::TShiftState Shift);
	virtual bool __fastcall IsANSICommand(const AnsiString Cmd);
};


//-- var, const, procedure ---------------------------------------------------
#define ANSITxtBlack "\x1b[30m"
#define ANSITxtRed "\x1b[31m"
#define ANSITxtGreen "\x1b[32m"
#define ANSITxtYellow "\x1b[33m"
#define ANSITxtBlue "\x1b[34m"
#define ANSITxtFuchsia "\x1b[35m"
#define ANSITxtAqua "\x1b[36m"
#define ANSITxtWhite "\x1b[37m"
#define ANSIBkgBlack "\x1b[40m"
#define ANSIBkgRed "\x1b[41m"
#define ANSIBkgGreen "\x1b[42m"
#define ANSIBkgYellow "\x1b[43m"
#define ANSIBkgBlue "\x1b[44m"
#define ANSIBkgFuchsia "\x1b[45m"
#define ANSIBkgAqua "\x1b[46m"
#define ANSIBkgWhite "\x1b[47m"

}	/* namespace Vaansiemulation */
using namespace Vaansiemulation;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VaANSIEmulation
