****************************************************

     Varian Async32 Components

     Varian Software NL (c) 1996-2000
     All Rights Reserved

****************************************************

Version: 1.54
Release date: April 2000
Release type: Freeware


Varian Async32 contains components, objects and routines 
for Borland Delphi with full source code. This library is 
designed for Borland Delphi 3/4/5 and C++ Builder 4. The 
library provides serial communications for your application 
by allowing the transmission and reception of data through 
a serial port.

We would be glad about some suggestions or some criticism 
for an improvement of this package. Therefore we hope for a 
large feedback! 

Delphi is a trademark of Inprise corp.

Varian Software is primarily a developer of add on tools for 
Delphi. We also provide custom programming and tool development 
at very reasonable rates. 

You are allowed to use the compiled (dcu release) in freeware, 
shareware or commercial software without registration. Source 
code and full support however is made available after registration 
of the library.

A license will include the following:

*  The latest version of the library, both compiled
   and source code via Internet E-mail or as disk version.

*  Free bug fixes, new components and upgrades until the 
   next major release.

*  Free technical support on usage and implementation


For more information on how to order see ORDER.TXT or the 
included help file.


Copyright (c) 2000 by Varian Software (Varian@Wxs.nl)

THIS SOFTWARE IS PROVIDED 'AS-IS', WITHOUT ANY EXPRESS OR IMPLIED
WARRANTY. IN NO EVENT WILL THE AUTHOR BE HELD LIABLE FOR ANY DAMAGES
ARISING FROM THE USE OF THIS SOFTWARE.

This notice may not be removed or altered from any source distribution.


      For any info or suggestions please feel free to write to:
             ***********************************
             **        Varian@Wxs.nl          **
             ***********************************

                   (c) Varian Software NL
